let board = [];
let playerGuess = [];
let guessOrder = [0, 0, 0, 0]
let guesses = 1 
/*board: Un array che rappresenta la sequenza segreta generata casualmente dal computer.
  playerGuess: Un array che contiene l'attuale tentativo del giocatore.
  guessOrder: Un array che tiene traccia dell'esito del confronto tra il tentativo del giocatore e la sequenza segreta.
  guesses: Un contatore per tenere traccia del numero di tentativi del giocatore.*/ 



/*Funzione game():
Inizializza il gioco chiamando la funzione computerBoard() 
per generare una sequenza segreta e imposta un gestore di eventi sul pulsante con l'ID 
"submit" per chiamare la funzione playRound().*/ 
  function game(){
    computerBoard();
    $('#submit').click(playRound)
}

//La funzione reset() reimposta tutte le variabili e l'aspetto del gioco.
$('#reset').click(reset);


/*Funzione playRound():
Controlla se il giocatore ha selezionato 4 colori validi.
Se i colori sono stati selezionati correttamente, converte i colori in numeri, confronta i tentativi e aggiorna l'interfaccia del gioco.
Controlla se il giocatore ha vinto o perso e gestisce di conseguenza.*/ 
function playRound(){
    let checkIfEmpty = 0
    $('.player-choice').each(function(){
        if($(this).css('background-color') == 'rgb(255, 255, 255)'){
            checkIfEmpty += 1
        }
    })
    if(checkIfEmpty > 0 ){
        alert("You must select 4 colors.")
    } else {
        playerGuess.push(colorToInt($('#playerChoice1')));
        playerGuess.push(colorToInt($('#playerChoice2')));
        playerGuess.push(colorToInt($('#playerChoice3')));
        playerGuess.push(colorToInt($('#playerChoice4')));
        compareGuesses();
        guessResults(guesses);
        checkWinner();
        $('.player-choice').css('background-color', 'rgb(255, 255, 255')
        playerGuess = []
        guesses++
    }
}


function reset(){
    board = []
    playerGuess = []
    guesses = 1
    guessOrder = [0, 0, 0, 0]
    $('.empty-row').css({
        'background-color' : 'rgb(255, 255, 255)',
        'border' : 'solid black 2px'
    })
    $('.player-choice').css('background-color', 'rgb(255, 255, 255')
    game();
}

/*Funzione checkWinner():
Verifica se il giocatore ha indovinato correttamente la sequenza segreta
o ha superato il numero massimo di tentativi consentiti.*/ 

function checkWinner(){
    if(guessOrder[0] + guessOrder[1] + guessOrder[2] + guessOrder[3] == 8){
        alert('You win! It only took you ' + guesses + ' guesses!')
        $('#submit').unbind();
       showSolution();
    } else if(guesses >= 10){
        alert('You lose. Better luck next time!')
        showSolution();
        $('#submit').unbind();
    } else {
        guessOrder = [0, 0, 0, 0]
    }
}


/*Funzione compareGuesses():
Confronta il tentativo del giocatore con la sequenza segreta per 
individuare corrispondenze esatte e parziali.*/ 
function compareGuesses(){
    let comparisonBoardComp = [...board];
    let comparisonBoardPlayer = [...playerGuess];

    //Primo passaggio attraverso il controllo dell'array per le corrispondenze esatte
    for(let i = 0; i < 4; i++){
        if(comparisonBoardComp[i] == comparisonBoardPlayer[i]){
            comparisonBoardComp.splice(i, 1, 4); //Replaces original choice with 4 to mark exact match
            comparisonBoardPlayer.splice(i, 1, 4);
            guessOrder.splice(i, 1, 2);
        }
    }

    //Secondo passaggio attraverso il controllo dell'array per corrispondenze parziali
    for(let i = 0; i < 4; i++){
        if(comparisonBoardPlayer[i] == 4){continue;}
        else if(comparisonBoardComp.includes(comparisonBoardPlayer[i])){
            guessOrder.splice(i, 1, 1);
            comparisonBoardComp.splice(comparisonBoardComp.indexOf(comparisonBoardPlayer[i]), 1); 
        }
    }
}

/*Funzione guessResults():
Aggiorna l'aspetto della griglia del gioco per riflettere i risultati del tentativo del giocatore.*/ 
function guessResults(n){
    let row = "#row" + n
    $(row).children().each(function(index, element){
        if(playerGuess[index] == 0){
            $(this).css('background-color', 'rgb(98, 0, 167)')
            if(guessOrder[index] == 2){
                $(this).css('border', 'solid green 4px')
            } else if (guessOrder[index] == 1){
                $(this).css('border', 'solid #f48f00 4px')
            } else {
                $(this).css('border', 'solid red 4px')
            }
        } else if (playerGuess[index] == 1){
            $(this).css('background-color', 'rgb(0, 69, 167)')
            if(guessOrder[index] == 2){
                $(this).css('border', 'solid green 4px')
            } else if (guessOrder[index] == 1){
                $(this).css('border', 'solid #f48f00 4px')
            } else {
                $(this).css('border', 'solid red 4px')
            }
        } else if (playerGuess[index] == 2){
            $(this).css('background-color', 'rgb(167, 98, 0)')
            if(guessOrder[index] == 2){
                $(this).css('border', 'solid green 4px')
            } else if (guessOrder[index] == 1){
                $(this).css('border', 'solid #f48f00 4px')
            } else {
                $(this).css('border', 'solid red 4px')
            }
        } else {
            $(this).css('background-color', 'rgb(69, 167, 0)')
            if(guessOrder[index] == 2){
                $(this).css('border', 'solid green 4px')
            } else if (guessOrder[index] == 1){
                $(this).css('border', 'solid #f48f00 4px')
            } else {
                $(this).css('border', 'solid red 4px')
            }
        }
    })
}


/*Funzione showSolution():
Mostra la soluzione corretta nella parte superiore del tabellone.*/ 
function showSolution(){
    $('#computerCombination').children().each(function(index, element){
        if(board[index] == 0){
            $(this).css('background-color', 'rgb(98, 0, 167)')
        } else if (board[index] == 1){
            $(this).css('background-color', 'rgb(0, 69, 167)')
        } else if (board[index] == 2){
            $(this).css('background-color', 'rgb(167, 98, 0)')
        } else {
            $(this).css('background-color', 'rgb(69, 167, 0)')
        }
    })
}

function borderColor(){
    if(guessOrder[index] == 2){
        $(this).css('border', 'solid green 4px')
    } else if (guessOrder[index] == 1){
        $(this).css('border', 'solid orange 4px')
    } else {
        $(this).css('border', 'solid red 4px')
    }
}

function computerBoard(){
    for(let i = 0; i < 4; i++){
        board.push(Math.floor(Math.random() * 4 ))
    }
}


/*Funzione colorToInt(color):
Converte il colore selezionato dal giocatore in un numero corrispondente.*/ 
function colorToInt(color){
    let bgColor = color.css('background-color')
    if( bgColor == 'rgb(98, 0, 167)'){
        return 0
    } else if(bgColor == 'rgb(0, 69, 167)'){
        return 1
    } else if(bgColor == 'rgb(167, 98, 0)'){
        return 2
    } else {
        return 3
    }
}

//Cambia il colore di sfondo del quadrato selezionato dal menu a discesa del giocatore
$('.color-select').click(function() {
    if($(this).hasClass("player-color-purple")){
        $(this).parentsUntil(".selection-bar").css('background-color', '#6200a7');
    }
    else if($(this).hasClass("player-color-blue")){
        $(this).parentsUntil(".selection-bar").css('background-color', '#0045a7');
    }
    else if($(this).hasClass("player-color-yellow")){
        $(this).parentsUntil(".selection-bar").css('background-color', '#a76200');
    }
    else if($(this).hasClass("player-color-green")){
        $(this).parentsUntil(".selection-bar").css('background-color', '#45a700');
    }
})


game();