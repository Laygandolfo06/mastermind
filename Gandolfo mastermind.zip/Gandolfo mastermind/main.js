window.onload = () => start(); //inizia il gioco

/*Selezionamento degli elementi del DOM:

I vari elementi del DOM vengono selezionati utilizzando document.querySelector e document.querySelectorAll. 
Questi elementi includono i pulsanti per i colori, le posizioni di gioco, le posizioni dei risultati, il pulsante "Play Again" e altri elementi.*/
const colours = document.querySelector('.colours'); 
const [...buttonsArr] = document.querySelectorAll('button'); 
//Ottieni pulsanti individuali per uno stile successivo
const blue = document.querySelector('.blue');
const red = document.querySelector('.red');
const yellow = document.querySelector('.yellow');
const green = document.querySelector('.green');
const purple = document.querySelector('.purple');
const white = document.querySelector('.white');

//pannello info
const info = document.querySelector('.info p');

//Ottieni tutte e quattro le ipotesi per ogni riga e inseriscile in un array
const [...one] = document.querySelectorAll('#one, #two, #three, #four');
const [...two] = document.querySelectorAll('#five, #six, #seven, #eight');
const [...three] = document.querySelectorAll('#nine, #ten, #eleven, #twelve');
const [...four] = document.querySelectorAll(
  '#thirteen, #fourteen, #fifteen, #sixteen'
);
const [...five] = document.querySelectorAll(
  '#seventeen, #eighteen, #nineteen, #twenty'
);
const [...six] = document.querySelectorAll(
  '#twentyone, #twentytwo, #twentythree, #twentyfour'
);
const [...seven] = document.querySelectorAll(
  '#twentyfive, #twentysix, #twentyseven, #twentyeight'
);
const [...eight] = document.querySelectorAll(
  '#twentynine, #thirty, #thirtyone, #thirtytwo'
);
const [...nine] = document.querySelectorAll(
  '#thirtythree, #thirtyfour, #thirtyfive, #thirtysix'
);
const [...ten] = document.querySelectorAll(
  '#thirtyseven, #thirtyeight, #thirtynine, #forty'
);

//risultati
const [...resultOne] = document.querySelectorAll('.resultOne .miniCircle');
const [...resultTwo] = document.querySelectorAll('.resultTwo .miniCircle');
const [...resultThree] = document.querySelectorAll('.resultThree .miniCircle');
const [...resultFour] = document.querySelectorAll('.resultFour .miniCircle');
const [...resultFive] = document.querySelectorAll('.resultFive .miniCircle');
const [...resultSix] = document.querySelectorAll('.resultSix .miniCircle');
const [...resultSeven] = document.querySelectorAll('.resultSeven .miniCircle');
const [...resultEight] = document.querySelectorAll('.resultEight .miniCircle');
const [...resultNine] = document.querySelectorAll('.resultNine .miniCircle');
const [...resultTen] = document.querySelectorAll('.resultTen .miniCircle');

//Pulsante Gioca di nuovo e codice nascosto da mostrare dopo la vincita
const playAgain = document.querySelector('.playAgain');
const playArea = document.querySelector('.playArea');
const hidden = document.querySelector('.hidden');
const [...hidden2] = document.querySelectorAll('.hidden .circle2');


let number = 0;
let result = 0;
let mysteryColours = [];
let colourSetArr = [];
let setCounter = 0;
let posCounter = 0;
let saveColour;
let winArr = [];
let colourSet;

//array colori
const coloursArray = [
  '',
  'radial-gradient(circle at 10px 10px, blue, rgb(1, 1, 44))',
  'radial-gradient(circle at 10px 10px, red, rgb(1, 1, 44))',
  'radial-gradient(circle at 10px 10px, yellow, rgb(1, 1, 44))',
  'radial-gradient(circle at 10px 10px, green, rgb(1, 1, 44))',
  'radial-gradient(circle at 10px 10px, purple, rgb(1, 1, 44))',
  'radial-gradient(circle at 10px 10px, white, rgb(1, 1, 44))'
];

//positioni da indovinare array
const boardPositions = [
  one,
  two,
  three,
  four,
  five,
  six,
  seven,
  eight,
  nine,
  ten
];

//risultati posizioni array
const resultPositions = [
  resultOne,
  resultTwo,
  resultThree,
  resultFour,
  resultFive,
  resultSix,
  resultSeven,
  resultEight,
  resultNine,
  resultTen
];

//bottoni(background-color)
blue.style =
  'background-color: blue; background: radial-gradient(circle at 10px 10px, blue, #01012c);';
red.style =
  'background-color: red; background: radial-gradient(circle at 10px 10px, red, #01012c);';
yellow.style =
  'background-color: yellow; background: radial-gradient(circle at 10px 10px, yellow, #01012c);';
green.style =
  'background-color: green; background: radial-gradient(circle at 10px 10px, green, #01012c);';
purple.style =
  'background-color: purple; background: radial-gradient(circle at 10px 10px, purple, #01012c);';
white.style =
  'background-color: white; background: radial-gradient(circle at 10px 10px, white, #01012c);';



//inizializzazione del gioco
const start = () => {
  buttonsArr.map(button => (button.disabled = false));
  playAgain.disabled = true;
  playAgain.style = 'opacity: 0';
  hidden.style = 'opacity: 0';
  playArea.style = 'opacity: 1';
  info.innerHTML = 'Please choose a colour';
  assignColours();
};



/*Funzione assignColours():
Crea una sequenza casuale di quattro colori chiamata mysteryColours e li inserisce in un set per garantire che siano tutti unici. 
Questa funzione viene chiamata all'inizio del gioco per impostare la sequenza segreta.*/ 
const assignColours = () => {
  for (let i = 0; i < 4; i++) {
    result = getRandomIntInclusive(1, 6);
    mysteryColours.push(coloursArray[result]);
  }
  colourSet = new Set(mysteryColours);
  if (colourSet.size < 4) {
    mysteryColours.length = 0;
    colourSet.clear();
    start();
  }
};

/*Funzione getRandomIntInclusive():
Una funzione di utilità che restituisce un numero intero casuale compreso tra i valori forniti come argomenti.*/ 
const getRandomIntInclusive = (min, max) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  number = Math.floor(Math.random() * (max - min + 1)) + min;
  return number;
};

/*Funzione putOnBoard(e):

Gestisce il posizionamento dei colori selezionati sulla tavola di gioco. 
Controlla le posizioni correnti sulla tavola e i contatori per determinare dove posizionare i colori.*/ 
const putOnBoard = e => {
  if (e.target.tagName === 'BUTTON') {
    boardPositions[setCounter][posCounter].style.background =
      e.target.style.background;
    posCounter++;
    if (posCounter === 4) {
      checkSequence();
      checkColours();
      checkResults();
      posCounter = 0;
      setCounter++;
    }
  }
};


/*Funzione checkSequence():

Controlla se i colori nella riga corrente sono nella posizione corretta rispetto alla sequenza segreta, 
e imposta il colore verde nei risultati corrispondenti.*/ 
const checkSequence = () => {
  boardPositions[setCounter].map((pos1, index) => {
    if (pos1.style.background === mysteryColours[index]) {
      resultPositions[setCounter][index].style =
        'background-color: green; background: radial-gradient(circle at 10px 10px, green, #01012c);';
    }
  });
};


/*Funzione checkColours():
Controlla se i colori nella riga corrente sono presenti nella sequenza segreta ma nella posizione sbagliata, 
e imposta il colore bianco nei risultati corrispondenti.*/ 
const checkColours = () => {
  resultPositions[setCounter].map((pos1, index1) => {
    if (pos1.style.background === '') {
      boardPositions[setCounter].map((pos2, index2) => {
        if (index1 === index2) {
          mysteryColours.map(colour => {
            if (pos2.style.background === colour) {
              pos1.style =
                'background-color: white; background: radial-gradient(circle at 10px 10px, white, #01012c);';
            }
          });
        }
      });
    }
  });
};


/*Funzione checkResults():
Verifica se tutti i risultati della riga corrente sono verdi, 
indicando che il giocatore ha indovinato correttamente la sequenza. 
In tal caso, mostra un messaggio di vittoria e abilita il pulsante "Play Again".*/ 
const checkResults = () => {
  winArr.length = 0;
  resultPositions[setCounter].map(pos => {
    if (
      pos.style.background !==
      'radial-gradient(circle at 10px 10px, green, rgb(1, 1, 44))'
    ) {
      winArr.push(false);
    } else {
      winArr.push(true);
    }
  });

  //determina i risultati
  let win = winArr.reduce((total, x) => (x === true ? total + x : null));

  //se 4 sono verdi abbiamo un vincitore

  if (win === 4) {
    info.innerHTML = 'You are a winner';
    playAgain.disabled = false;
    buttonsArr.map(button => (button.disabled = true));
    playAgain.style = 'opacity: 1;cursor: pointer';
    mysteryColours.map((colour, index) => {
      hidden2[index].style.background = colour;
    });
    hidden.style = 'opacity: 1';
    playArea.style = 'opacity: 0.3';
  } else {
    info.innerHTML = 'Please continue';
  }
};

//se pulsante gioca ancora viene premuto, resetta il tutto
/*Funzione clearDown():
Resetta tutte le posizioni di gioco e i risultati. Viene chiamata quando il giocatore preme il pulsante "Play Again".*/ 
const clearDown = () => {
  resultPositions.map(pos => {
    pos.map(colour => (colour.style.background = ''));
  });
  boardPositions.map(pos => {
    pos.map(colour => (colour.style.background = ''));
  });
  setCounter = 0;
  mysteryColours.length = 0;
  colourSet.clear();
  start();
};

/*Ascoltatori degli eventi:

Viene aggiunto un ascoltatore di eventi al contenitore dei colori (colours), che chiama la funzione putOnBoard(e) quando si fa clic su un colore.
Viene aggiunto un ascoltatore di eventi al pulsante "Play Again" (playAgain), che chiama la funzione clearDown() quando viene premuto.*/ 
colours.addEventListener('click', e => putOnBoard(e));
playAgain.addEventListener('click', () => clearDown());
